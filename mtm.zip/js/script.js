$('.dropdown-menu').mouseover(function() {
    $(this).children("ul").show(200);}